document.addEventListener("DOMContentLoaded", () => {
    initHomePage();
    initMovieListing();
    initMovieDetails();
    initFavoritesPage();
});

function createMovieCard(movie) {
    const isFav = isMovieFavorite(movie.id);
    const card = document.createElement("div");
    card.className = "movie-card";
    card.innerHTML = `
        <img src="${movie.poster}" alt="${movie.title}" class="movie-poster">
        <div class="movie-info">
            <h3 class="movie-title">${movie.id}. ${movie.title}</h3>
            <p class="movie-meta"><span>${movie.genre}</span> • <span>${movie.year}</span> • <span>${movie.language}</span></p>
            <p class="movie-rating">★ ${movie.rating} / 10</p>
            <p class="movie-desc">${movie.description}</p>
            <div class="card-btn-group">
                <a href="movie-details.html?id=${movie.id}" class="btn-card">View Details</a>
                <button class="btn-fav ${isFav ? 'active' : ''}" data-id="${movie.id}">
                    ${isFav ? '★ Watchlisted' : '☆ Add to Watchlist'}
                </button>
            </div>
        </div>
    `;

    const favButton = card.querySelector(".btn-fav");
    favButton.addEventListener("click", () => {
        const added = toggleFavorite(movie.id);
        favButton.classList.toggle("active", added);
        favButton.innerText = added ? "★ Watchlisted" : "☆ Add to Watchlist";

        if (document.getElementById("favoritesGrid")) {
            renderFavoritesList();
        }
    });

    return card;
}

function initHomePage() {
    const homeFeaturedContainer = document.getElementById("featuredGrid");
    if (!homeFeaturedContainer) return;

    homeFeaturedContainer.innerHTML = "";
    const topRated = [...moviesData].sort((a, b) => b.rating - a.rating).slice(0, 4);
    topRated.forEach(movie => {
        homeFeaturedContainer.appendChild(createMovieCard(movie));
    });
}

function initMovieListing() {
    const movieGrid = document.getElementById("movieListingGrid");
    if (!movieGrid) return;

    const searchInput = document.getElementById("searchInput");
    const genreFilter = document.getElementById("genreFilter");
    const langFilter = document.getElementById("langFilter");
    const sortSelect = document.getElementById("sortSelect");

    function applyFilters() {
        const query = searchInput ? searchInput.value.trim().toLowerCase() : "";
        const selectedGenre = genreFilter ? genreFilter.value : "All";
        const selectedLang = langFilter ? langFilter.value : "All";
        const selectedSort = sortSelect ? sortSelect.value : "default";

        let filtered = moviesData.filter(movie => {
            const matchesQuery = movie.title.toLowerCase().includes(query) || movie.description.toLowerCase().includes(query);
            const matchesGenre = selectedGenre === "All" || movie.genre.toLowerCase() === selectedGenre.toLowerCase();
            const matchesLang = selectedLang === "All" || movie.language.toLowerCase() === selectedLang.toLowerCase();
            return matchesQuery && matchesGenre && matchesLang;
        });

        if (selectedSort === "rating-desc") {
            filtered.sort((a, b) => b.rating - a.rating);
        } else if (selectedSort === "rating-asc") {
            filtered.sort((a, b) => a.rating - b.rating);
        } else if (selectedSort === "year-desc") {
            filtered.sort((a, b) => b.year - a.year);
        } else if (selectedSort === "year-asc") {
            filtered.sort((a, b) => a.year - b.year);
        } else if (selectedSort === "title-asc") {
            filtered.sort((a, b) => a.title.localeCompare(b.title));
        } else if (selectedSort === "title-desc") {
            filtered.sort((a, b) => b.title.localeCompare(a.title));
        }

        movieGrid.innerHTML = "";
        const countDisplay = document.getElementById("movieCount");
        if (countDisplay) {
            countDisplay.innerText = `(${filtered.length})`;
        }

        if (filtered.length === 0) {
            movieGrid.innerHTML = `<p class="no-results">No movies match your selected criteria.</p>`;
            return;
        }

        filtered.forEach(movie => {
            movieGrid.appendChild(createMovieCard(movie));
        });
    }

    if (searchInput) searchInput.addEventListener("input", applyFilters);
    if (genreFilter) genreFilter.addEventListener("change", applyFilters);
    if (langFilter) langFilter.addEventListener("change", applyFilters);
    if (sortSelect) sortSelect.addEventListener("change", applyFilters);

    applyFilters();
}

function initMovieDetails() {
    const detailsContainer = document.getElementById("movieDetailsContainer");
    if (!detailsContainer) return;

    const urlParams = new URLSearchParams(window.location.search);
    const movieId = parseInt(urlParams.get("id"), 10) || 1;
    const movie = moviesData.find(m => m.id === movieId);

    if (!movie) {
        detailsContainer.innerHTML = `<p class="no-results">Movie not found.</p>`;
        return;
    }

    document.title = `${movie.title} - Movie Details`;

    detailsContainer.innerHTML = `
        <div class="details-poster">
            <img src="${movie.poster}" alt="${movie.title}">
        </div>
        <div class="details-content">
            <h1>${movie.title} (${movie.year})</h1>
            <p class="details-meta"><strong>Genre:</strong> ${movie.genre} | <strong>Duration:</strong> ${movie.duration} | <strong>Language:</strong> ${movie.language}</p>
            <p class="movie-rating">★ ${movie.rating} / 10</p>
            <p class="details-desc">${movie.description}</p>
            <p><strong>Director:</strong> ${movie.director}</p>
            <p><strong>Cast:</strong> ${movie.cast}</p>
            <div class="trailer-box">
                <h3>Official Trailer</h3>
                <iframe width="100%" height="315" src="${movie.trailer}" title="${movie.title} Trailer" frameborder="0" allowfullscreen></iframe>
            </div>
            <div style="margin-top: 20px; display: flex; gap: 15px;">
                <a href="movies.html" class="btn-primary">Back to Movies</a>
                <button id="detailFavBtn" class="btn-card">
                    ${isMovieFavorite(movie.id) ? '★ Remove from Watchlist' : '☆ Add to Watchlist'}
                </button>
            </div>
        </div>
    `;

    const detailFavBtn = document.getElementById("detailFavBtn");
    detailFavBtn.addEventListener("click", () => {
        const added = toggleFavorite(movie.id);
        detailFavBtn.innerText = added ? '★ Remove from Watchlist' : '☆ Add to Watchlist';
    });
}

function initFavoritesPage() {
    const favoritesGrid = document.getElementById("favoritesGrid");
    if (!favoritesGrid) return;
    renderFavoritesList();
}

function renderFavoritesList() {
    const favoritesGrid = document.getElementById("favoritesGrid");
    const countDisplay = document.getElementById("favoriteCount");
    const favoriteIds = getFavorites();
    const favMovies = moviesData.filter(movie => favoriteIds.includes(movie.id));

    favoritesGrid.innerHTML = "";
    if (countDisplay) {
        countDisplay.innerText = `(${favMovies.length})`;
    }

    if (favMovies.length === 0) {
        favoritesGrid.innerHTML = `<p class="no-results">Your watchlist is currently empty. Go to the movie directory to add some!</p>`;
        return;
    }

    favMovies.forEach(movie => {
        const card = document.createElement("div");
        card.className = "movie-card";
        card.innerHTML = `
            <img src="${movie.poster}" alt="${movie.title}" class="movie-poster">
            <div class="movie-info">
                <h3 class="movie-title">${movie.id}. ${movie.title}</h3>
                <p class="movie-meta"><span>${movie.genre}</span> • <span>${movie.year}</span></p>
                <p class="movie-rating">★ ${movie.rating} / 10</p>
                <div class="card-btn-group">
                    <a href="movie-details.html?id=${movie.id}" class="btn-card">View</a>
                    <button class="btn-card btn-remove" data-id="${movie.id}">Remove</button>
                </div>
            </div>
        `;

        card.querySelector(".btn-remove").addEventListener("click", () => {
            toggleFavorite(movie.id);
            renderFavoritesList();
        });

        favoritesGrid.appendChild(card);
    });
}