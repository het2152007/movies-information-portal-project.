function getFavorites() {
    const stored = localStorage.getItem("moviePortalFavorites");
    return stored ? JSON.parse(stored) : [];
}

function saveFavorites(favorites) {
    localStorage.setItem("moviePortalFavorites", JSON.stringify(favorites));
}

function isMovieFavorite(movieId) {
    const favorites = getFavorites();
    return favorites.includes(movieId);
}

function toggleFavorite(movieId) {
    let favorites = getFavorites();
    const id = parseInt(movieId, 10);
    if (favorites.includes(id)) {
        favorites = favorites.filter(favId => favId !== id);
    } else {
        favorites.push(id);
    }
    saveFavorites(favorites);
    return isMovieFavorite(id);
}