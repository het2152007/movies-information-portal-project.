document.addEventListener("DOMContentLoaded", () => {
    initReviewSystem();
    initContactForm();
});

const defaultReviews = [
    { name: "Aarav S.", movie: "Inception", rating: 9.5, review: "Mind-bending plot, incredible practical visual effects, and a haunting score." },
    { name: "Priya M.", movie: "Interstellar", rating: 9.0, review: "An emotional journey mixed with hard sci-fi physics. Nolan at his finest." },
    { name: "Karan D.", movie: "The Dark Knight", rating: 10, review: "Heath Ledger's Joker performance sets the benchmark for superhero cinema." },
    { name: "Neha T.", movie: "Spirited Away", rating: 9.2, review: "Studio Ghibli's hand-drawn animation brings a fantasy world to life seamlessly." },
    { name: "Vikram R.", movie: "Pulp Fiction", rating: 8.9, review: "Non-linear storytelling combined with iconic dialogue and flawless casting." }
];

function getStoredReviews() {
    const stored = localStorage.getItem("moviePortalReviews");
    return stored ? JSON.parse(stored) : defaultReviews;
}

function saveStoredReviews(reviews) {
    localStorage.setItem("moviePortalReviews", JSON.stringify(reviews));
}

function renderReviewsList() {
    const listContainer = document.getElementById("reviewsListGrid");
    if (!listContainer) return;

    const reviews = getStoredReviews();
    listContainer.innerHTML = "";

    reviews.forEach(item => {
        const card = document.createElement("div");
        card.className = "movie-card";
        card.innerHTML = `
            <div class="movie-info">
                <h3 class="movie-title">${item.movie}</h3>
                <p class="movie-meta">Reviewed by <strong>${item.name}</strong></p>
                <p class="movie-rating">★ ${item.rating} / 10</p>
                <p class="movie-desc">"${item.review}"</p>
            </div>
        `;
        listContainer.appendChild(card);
    });
}

function initReviewSystem() {
    const reviewForm = document.getElementById("reviewForm");
    const movieSelect = document.getElementById("movie-select");

    if (movieSelect && typeof moviesData !== "undefined") {
        moviesData.forEach(movie => {
            const option = document.createElement("option");
            option.value = movie.title;
            option.textContent = `${movie.id}. ${movie.title}`;
            movieSelect.appendChild(option);
        });
    }

    renderReviewsList();

    if (!reviewForm) return;

    reviewForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const nameInput = document.getElementById("reviewer-name");
        const movieInput = document.getElementById("movie-select");
        const ratingInput = document.getElementById("rating");
        const reviewTextInput = document.getElementById("review-text");
        const statusMessage = document.getElementById("reviewStatusMessage");

        const nameVal = nameInput.value.trim();
        const movieVal = movieInput.value;
        const ratingVal = parseFloat(ratingInput.value);
        const reviewVal = reviewTextInput.value.trim();

        if (nameVal.length < 2) {
            showFormFeedback(statusMessage, "Please enter a valid reviewer name (at least 2 letters).", false);
            return;
        }

        if (!movieVal) {
            showFormFeedback(statusMessage, "Please select a movie to review.", false);
            return;
        }

        if (isNaN(ratingVal) || ratingVal < 1 || ratingVal > 10) {
            showFormFeedback(statusMessage, "Rating must be an integer or decimal between 1 and 10.", false);
            return;
        }

        if (reviewVal.length < 10) {
            showFormFeedback(statusMessage, "Review commentary must be at least 10 characters long.", false);
            return;
        }

        const currentReviews = getStoredReviews();
        currentReviews.unshift({
            name: nameVal,
            movie: movieVal,
            rating: ratingVal,
            review: reviewVal
        });
        saveStoredReviews(currentReviews);

        renderReviewsList();
        reviewForm.reset();
        showFormFeedback(statusMessage, "Review submitted and displayed successfully!", true);
    });
}

function initContactForm() {
    const contactForm = document.getElementById("contactForm");
    if (!contactForm) return;

    contactForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const name = document.getElementById("contact-name").value.trim();
        const email = document.getElementById("contact-email").value.trim();
        const subject = document.getElementById("contact-subject").value.trim();
        const message = document.getElementById("contact-message").value.trim();
        const statusMessage = document.getElementById("contactStatusMessage");

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (name.length < 2) {
            showFormFeedback(statusMessage, "Please enter your name.", false);
            return;
        }

        if (!emailRegex.test(email)) {
            showFormFeedback(statusMessage, "Please enter a valid email address.", false);
            return;
        }

        if (subject.length < 3) {
            showFormFeedback(statusMessage, "Subject must be at least 3 characters.", false);
            return;
        }

        if (message.length < 10) {
            showFormFeedback(statusMessage, "Message must contain at least 10 characters.", false);
            return;
        }

        contactForm.reset();
        showFormFeedback(statusMessage, "Thank you! Your feedback message has been delivered.", true);
    });
}

function showFormFeedback(element, text, isSuccess) {
    if (!element) return;
    element.innerText = text;
    element.className = isSuccess ? "form-feedback success" : "form-feedback error";
    element.style.display = "block";
    setTimeout(() => {
        element.style.display = "none";
    }, 4500);
}